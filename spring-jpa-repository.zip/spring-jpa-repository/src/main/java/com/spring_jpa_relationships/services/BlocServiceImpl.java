package com.spring_jpa_relationships.services;

public class BlocServiceImpl {
}
