package com.spring_jpa_relationships.services;

public interface IBloc {
}
